function TodoItem({value,indexNumber,Todolist,setTodolist}){
  let deleteList = ()=>{
    let final = Todolist.filter((v,i)=>
       i!=indexNumber)
    // console.log(finall)
      setTodolist(final)
    
  }
  return(
    <li> {indexNumber+1} {value} <span onClick={deleteList}>&times;</span></li>
  )
}
export default TodoItem;