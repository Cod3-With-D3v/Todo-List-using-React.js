import { useState } from "react";
import "./App.css";
import TodoItem from "./todoItem";

export default function App() {
  let [Todolist, setTodolist] = useState([]);
  let addTodo = (event) => {
    let toname = event.target.toname.value;
    if (!Todolist.includes(toname)) {
      let finalTodo = [...Todolist, toname];
      setTodolist(finalTodo);
    } else {
      alert(toname + " is already in the list");
    }

    event.preventDefault();
  };
  let list = Todolist.map((value, index) => {
    return (
      <TodoItem
        value={value}
        key={index}
        indexNumber={index}
        Todolist={Todolist}
        setTodolist={setTodolist}
      />
    );
  });

  return (
    <main>
      <h1>TODO List</h1>
      <form onSubmit={addTodo}>
        <input
          className="input"
          type="text"
          name="toname"
          placeholder="Add a new todo"
        />
        <button>Submit</button>
      </form>
      <div className="outerdiv">
        <ul>{list}</ul>
      </div>
    </main>
  );
}
